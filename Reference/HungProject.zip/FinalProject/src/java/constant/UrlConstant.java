/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package constant;

/**
 *
 * @author ahhun
 */
public class UrlConstant {
    public static final String CGV_BASE_DETAIL_URL = "https://www.cgv.vn/default";
    public static final String CGV_NOW_SHOWING_URL = "https://www.cgv.vn/default/movies/now-showing.html";
    public static final String CGV_SCHEDULE_URL = "https://www.cgv.vn/default/cinemas/product/ajaxschedule";
    
    public static final String LOTTE_DETAIL_EN_URL = "https://lottecinemavn.com/en-us";
    public static final String LOTTE_DETAIL_VI_URL = "https://lottecinemavn.com/vi-vn";
    public static final String LOTTE_HOME_URL = "https://lottecinemavn.com/vi-vn/phim.aspx";
    
    public static final String GOOGLE_MAPS_API_KEY = "AIzaSyBW1y4yWGVRgi7eAgf5__xCIZ1o8iT3gf0";
    public static final String GOOGLE_MAPS_TEXT_SEARCH = "https://maps.googleapis.com/maps/api/place/textsearch/xml?";
}
